module compositeExam {
}