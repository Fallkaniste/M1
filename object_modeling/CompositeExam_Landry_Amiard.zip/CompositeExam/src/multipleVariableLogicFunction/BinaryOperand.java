package multipleVariableLogicFunction;

public abstract class BinaryOperand extends Satisfiable{

	public abstract void setLeftOperand(Satisfiable A);
	
	public abstract void setRightOperand(Satisfiable A);

}
