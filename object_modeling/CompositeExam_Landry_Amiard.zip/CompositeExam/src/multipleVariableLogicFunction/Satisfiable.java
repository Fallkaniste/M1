package multipleVariableLogicFunction;

public abstract class Satisfiable {

	public abstract boolean isSatisfiable();
	
}
