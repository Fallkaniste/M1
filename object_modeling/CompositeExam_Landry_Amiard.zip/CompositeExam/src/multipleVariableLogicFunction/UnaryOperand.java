package multipleVariableLogicFunction;

public abstract class UnaryOperand extends Satisfiable {

	public abstract void setOperande(Satisfiable a);

}
